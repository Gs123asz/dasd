from Cryptodome import Random
import base64
import hashlib
from Cryptodome.Cipher import AES
from Cryptodome.Util import Padding
unpad = lambda s : s[:-ord(s[len(s)-1:])]
import sys, getopt,os
import Cryptodome
application_path = os.path.dirname(sys.executable)

class AESTool(object):

    def __init__(self, iv, key):
        self.iv = iv
        self.key = key
        bs = AES.block_size
        self.pad = lambda s: s + (bs - len(s) % bs) * chr(bs - len(s) % bs)
        self.unpad = lambda s: s[0:-ord(s[-1])]

    def encrypt(self, plain_text):
        try:
            encryptor = AES.new(self.key, AES.MODE_CBC, self.iv)
            encrypted_text = base64.encodebytes(encryptor.encrypt(self.pad(plain_text).encode("utf8"))).decode()
        except Exception as ex:
            raise Exception(ex)

        return encrypted_text

    def decrypt(self, decrypted_text):
        try:
            decryptor = AES.new(self.key, AES.MODE_CBC, self.iv)
            plain_text = decryptor.decrypt(base64.decodebytes(str(decrypted_text).encode()))
        except Exception as ex:
            raise Exception(ex)

        return unpad(plain_text).decode()

    def encrypt_file(self, from_full_path, to_full_path, chunksize=64*1024):
        encryptor = AES.new(self.key, AES.MODE_CBC, self.iv)
        try:
            with open(from_full_path, 'rb') as infile:
                with open(to_full_path, 'wb') as outfile:
                    while True:
                        chunk = infile.read(chunksize)

                        if len(chunk) == 0:
                            break

                        if len(chunk) < chunksize:
                            outfile.write(encryptor.encrypt(self.pad(chunk)))
                            break

                        outfile.write(encryptor.encrypt(chunk))
        except Exception as ex:
            return -1

        return 0

    def decrypt_file(self, from_full_path, to_full_path, chunksize=64*1024):
        decryptor = AES.new(self.key, AES.MODE_CBC, self.iv)
        try:
            with open(from_full_path, 'rb') as infile:
                with open(to_full_path, 'wb') as outfile:
                    prev_chunk = None
                    while True:
                        chunk = infile.read(chunksize)

                        if len(chunk) == 0 and prev_chunk:
                            outfile.write(unpad(decryptor.decrypt(prev_chunk)))
                            break

                        if prev_chunk:
                            outfile.write(decryptor.decrypt(prev_chunk))

                        if len(chunk) < chunksize:
                            outfile.write(unpad(decryptor.decrypt(chunk)))
                            break

                        prev_chunk = chunk
        except Exception as ex:
            print(ex)
            return -1

        return 0

class AESCipher(object):
    def __init__(self, key): 
        self.bs = AES.block_size
        self.key = hashlib.sha256(key.encode()).digest()
        self.mode = AES.MODE_CBC

    def encrypt(self, raw):
        raw = self._pad(raw)
        iv = Random.new().read(AES.block_size)
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        return base64.b64encode(iv + cipher.encrypt(raw.encode()))

    def decrypt(self, enc):
        iv = enc[:16]
        enc= enc[16:]
        cipher = AES.new(self.key, AES.MODE_CBC, iv)

        return Padding.unpad(cipher.decrypt(enc),AES.block_size)
    


    def _pad(self, s):
        return s + (self.bs - len(s) % self.bs) * chr(self.bs - len(s) % self.bs)



if __name__ == "__main__":
    inputfile = ''
    outputfile = ''
    key = ''
    mode = ''
    opts, args = getopt.getopt(sys.argv[1:],"hi:o:k:m:",["ifile=","ofile=","key=","mode="])
    iv = bytearray(16)
    for opt, arg in opts:
        if opt == '-h':
            print ('name.exe -i <inputfile> -o <outputfile> -k <key> -m <mode>')
            print("     - mode = encFile, decFile, enc, dec")
            sys.exit()
        elif opt in ("-k","--key"):
            key = arg
        elif opt in ("-i", "--ifile"):
            inputfile = arg
        elif opt in ("-o", "--ofile"):
            outputfile = arg
        elif opt in ("-m", "--mode"):
            mode = arg
    

    c = AESTool(iv,hashlib.sha256(key.encode()).digest())
    
    if mode == "decFile": 
        c.decrypt_file(inputfile,outputfile)
    elif mode == "encFile":
        c.encrypt_file(inputfile,outputfile)
    elif mode == "enc":
        print(c.encrypt(inputfile))
    elif mode == "dec":
        print(c.decrypt(inputfile))
