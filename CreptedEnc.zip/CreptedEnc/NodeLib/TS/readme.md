# TypeScript verision
this is crepted lib at typescript

how to use:
-   first run npm install to this lib with the packeges that in packege json
- use the setup function to get crepted lib


# Exemple
    const crepted = await setup(
        "../../public_key.pem",
        "../../decryptFile.exe",
        "../../private_key.pem"
    )

# Addons
importent! our libery need decryptFile.exe file to work this file is compiled from python script 
you can find this file at Addones Libery