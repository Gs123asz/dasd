import crypto from 'crypto'
import { promisify } from 'util'
import {exec} from "child_process"
import fs from 'fs'
import forge from 'node-forge'
import path from "path"
import JsZip, { file } from 'Jszip'

const pki = forge.pki;

const readFileSync = promisify(fs.readFile)
const writeFileSync = promisify(fs.writeFile)
const execSync = promisify(exec)
const existsSync = promisify(fs.exists)
const rmSync = promisify(fs.rm)


const tempFilePathInput = "./tmp"
const tempFilePathOutput = "./tmpOut"

class Crepted
{
    private publicKey : forge.pki.rsa.PublicKey
    private privateKey? : forge.pki.rsa.PrivateKey | undefined
    private decryptFileExe : string

    constructor( publicKey : forge.pki.rsa.PublicKey, privateKey : forge.pki.rsa.PrivateKey | undefined, decryptFileExe : string){
        this.publicKey = publicKey
        this.privateKey = privateKey
        this.decryptFileExe = decryptFileExe
    }

    decryptRSA(token : string) : string {
        if(this.privateKey){
            return forge.util.decode64(
                this.privateKey.decrypt(
                    forge.util.decode64(token), "RSA-OAEP",{
                        md : forge.md.sha256.create(),
                        mgf1 : {
                            md : forge.md.sha256.create()
                        }
                    }
                )
            ).replace(/\s/g, '')
        }
        return ""
    }
    
    encryptRSA(token : string) : string{
        return forge.util.encode64(this.publicKey.encrypt(
            forge.util.encode64(token),"RSA-OAEP",{
                md : forge.md.sha256.create(),
                mgf1 : {
                    md : forge.md.sha256.create()
                }
            }
        ).toString())
    }

    async decryptFile(inputFilePath : string, outputFilePath : string, key : string) : Promise<string>{
        const res = await execSync(`"${this.decryptFileExe}" -i "${path.resolve(inputFilePath)}" -o "${path.resolve(outputFilePath)}" -k "${key}" -m decFile`)
        console.log(res.stderr)
        return outputFilePath
    }
    
    async encryptAES(data : string, key : string) : Promise<string>{
        const res = await execSync(`"${this.decryptFileExe}" -i "${data}" -k "${key}" -m "enc"`)
        return res.stdout.replace(/\s/g, '')
    }
    async decryptAES(data : string, key : string) : Promise<string> {
        const res = await execSync(`"${this.decryptFileExe}" -i "${data}" -k "${key}" -m "dec"`)
        return res.stdout.replace(/\s/g, '')
    }
 

    private async findKeyFile(zip: JsZip) : Promise<string | null>{
        for(const fileName in zip.files){
            if ( fileName == "key.bin" || fileName == "Key.bin"){
                return this.decryptRSA(await zip.files[fileName].async("binarystring"))
            }
        }

        return null
    }

    async decryptAesRsa(zipPath : string, isPath : boolean = true) : Promise<Buffer>{
        const zipData = await readFileSync(path.resolve(zipPath))
        const zip = await (new JsZip().loadAsync(zipData))
        const key = await this.findKeyFile(zip)
        
        if(key == null) throw "Error with found key in the format";
        console.log(key)

        const newZip = new JsZip()
        for(const fileName in zip.files){
            if ( fileName == "key.bin" || fileName == "Key.bin"){ 
                continue
            }
            await writeFileSync(tempFilePathInput,await zip.files[fileName].async("nodebuffer"))
            newZip.file(
                fileName, 
                await readFileSync(
                    await this.decryptFile(
                        tempFilePathInput,
                        tempFilePathOutput,
                        key
                    )
                )
            )
            await rmSync(
                tempFilePathOutput
            )
            await rmSync(
                tempFilePathInput 
            )  
       }

       if (await existsSync(tempFilePathOutput)){
            await rmSync(
                tempFilePathOutput
            )
       }
       
       if (await existsSync(tempFilePathInput)){
            await rmSync(
                tempFilePathInput
            )
        }

       return await newZip.generateAsync({
            type: 'nodebuffer',
            mimeType: 'application/epub+zip',
       })

        
    } 
}


const setup = async (publicKey : string, decryptFileExe : string, privateKey? : string) : Promise<Crepted> =>{
    return new Crepted (
        pki.publicKeyFromPem((await readFileSync(publicKey)).toString("utf-8")),
        privateKey ? pki.privateKeyFromPem((await readFileSync(privateKey)).toString("utf-8")) : undefined,
        decryptFileExe
    )
}


export default setup