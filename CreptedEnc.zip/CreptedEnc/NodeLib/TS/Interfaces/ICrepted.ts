export interface ICrepted {
    publicKey : string
    privateKey? : string 
}