# This is crepted libery for any encryption that we using
 
Our custome RSA-AES Format

zip file with files and key.bin file that hold the aes key for those files.

<br /><br />
# Supported Encryptions
 
 ### AES
 -  CBC 128, 256
 - EBC 128, 256
 ### RSA
 - RSA-OEAP 2048, 4026
<br /><br />
# Format

Our foramt for rsa aes file is zip file that include an a aes key in file with the name key.bin


# Current Support
our libery is currenlty supported in TypeScript, Js, Python, Kotlin, Java.